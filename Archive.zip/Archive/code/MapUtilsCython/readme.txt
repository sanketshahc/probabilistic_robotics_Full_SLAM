To test the code, you may need to install the package cython in your 
computer. Then compile the cython file:

python ./setup.py build_ext --inplace

After compiling the file, you should test the test file:
test_getMapCellsFromRay.py
